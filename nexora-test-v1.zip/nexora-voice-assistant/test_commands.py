"""
Tests for Nexora's command parser (nexora_commands.py).

Run:
    python test_commands.py

Every test prints PASS/FAIL. The last line prints the total count.
No third-party libraries needed.
"""

from nexora_commands import parse_command

# (sentence, expected action, expected query/text or None)
CASES = [
    # open_word
    ("open word", "open_word", None),
    ("word kholo", "open_word", None),
    ("Open MS Word!", "open_word", None),
    ("microsoft word kholo", "open_word", None),
    # open_chrome
    ("open chrome", "open_chrome", None),
    ("chrome kholo", "open_chrome", None),
    ("open google chrome", "open_chrome", None),
    # open_notepad
    ("open notepad", "open_notepad", None),
    ("notepad kholo", "open_notepad", None),
    # open_calculator
    ("open calculator", "open_calculator", None),
    ("calculator kholo", "open_calculator", None),
    # open_paint
    ("open paint", "open_paint", None),
    ("paint kholo", "open_paint", None),
    # open_explorer
    ("open explorer", "open_explorer", None),
    ("file explorer kholo", "open_explorer", None),
    ("open files", "open_explorer", None),
    # open_youtube
    ("open youtube", "open_youtube", None),
    ("youtube kholo", "open_youtube", None),
    # open_google
    ("open google", "open_google", None),
    ("google kholo", "open_google", None),
    # google_search
    ("search for cats", "google_search", "cats"),
    ("google search weather today", "google_search", "weather today"),
    ("pakistan ki news search karo", "google_search", "pakistan ki news"),
    ("search karo cricket score", "google_search", "cricket score"),
    # youtube_search
    ("youtube search funny videos", "youtube_search", "funny videos"),
    ("youtube par songs search karo", "youtube_search", "songs"),
    ("search youtube for nasheed", "youtube_search", "nasheed"),
    # dictate / type
    ("likho mera naam Ahmad hai", "dictate", "mera naam Ahmad hai"),
    ("type hello world", "dictate", "hello world"),
    ("write this is a test", "dictate", "this is a test"),
    # open_pictures
    ("open photos", "open_pictures", None),
    ("photo kholo", "open_pictures", None),
    ("pictures kholo", "open_pictures", None),
    # open_videos
    ("open videos", "open_videos", None),
    ("video kholo", "open_videos", None),
    # open_downloads
    ("open downloads", "open_downloads", None),
    ("downloads kholo", "open_downloads", None),
    # tell_time
    ("what is the time", "tell_time", None),
    ("time batao", "tell_time", None),
    ("waqt kya hai", "tell_time", None),
    # tell_date
    ("what is the date", "tell_date", None),
    ("aaj ki tarikh batao", "tell_date", None),
    ("date batao", "tell_date", None),
    # close_window
    ("close this", "close_window", None),
    ("band karo", "close_window", None),
    ("close window", "close_window", None),
    # volume
    ("volume up", "volume_up", None),
    ("awaz tez karo", "volume_up", None),
    ("volume down", "volume_down", None),
    ("awaz kam karo", "volume_down", None),
    ("mute", "mute", None),
    ("awaz band karo", "mute", None),
    # greet
    ("hello", "greet", None),
    ("salam", "greet", None),
    ("hello nexora", "greet", None),
    # unknown
    ("asdf qwer zxcv", "unknown", None),
    ("bananas are yellow fruit", "unknown", None),
    ("", "unknown", None),
]


def main():
    passed = 0
    failed = 0
    for sentence, expected_action, expected_payload in CASES:
        result = parse_command(sentence)
        ok = result.get("action") == expected_action
        if ok and expected_payload is not None:
            payload = result.get("query", result.get("text", ""))
            ok = str(payload).lower() == expected_payload.lower()
        if ok:
            passed += 1
            print(f"PASS  {sentence!r:45} -> {result}")
        else:
            failed += 1
            print(f"FAIL  {sentence!r:45} -> got {result}, expected action={expected_action} payload={expected_payload}")
    print()
    print(f"RESULT: {passed} passed, {failed} failed, {passed + failed} total")
    return failed


if __name__ == "__main__":
    raise SystemExit(1 if main() else 0)
