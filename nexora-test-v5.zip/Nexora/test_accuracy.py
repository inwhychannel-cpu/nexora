"""
Accuracy tests for Nexora v4 - the "never do the WRONG thing" suite.

These cases pin down the accuracy rule in nexora_commands.py:
an action fires only when the command phrase is the MAIN INTENT of
the sentence (anchored at the start/end, or the exact bare name).
A target/close/volume/time word inside a longer unrelated sentence
must return "unknown" so Nexora does nothing instead of misfiring.

Run:
    python test_accuracy.py

Every test prints PASS/FAIL. The last line prints the total count.
No third-party libraries needed.
"""

from nexora_commands import parse_command
from nexora_i18n_commands import parse_command_v2

# (sentence, expected action, expected query/text or None)
CASES = [
    # --- Search beats open: the query may contain target words ---
    ("search youtube for funny cats", "youtube_search", "funny cats"),
    ("search google for word games", "google_search", "word games"),
    ("search google for the word document", "google_search", "word document"),
    ("search for word", "google_search", "word"),
    ("google par pizza search karo", "google_search", "pizza"),
    ("youtube par songs search karo", "youtube_search", "songs"),
    ("search for cats", "google_search", "cats"),
    # --- Search beats volume / close / time words inside the query ---
    ("search youtube for volume up songs", "youtube_search", "volume up songs"),
    ("search google for close window curtains", "google_search", "close window curtains"),
    ("search google for time zones", "google_search", "time zones"),
    ("search google for mute sounds", "google_search", "mute sounds"),
    # --- Plain open commands still work exactly ---
    ("open youtube", "open_youtube", None),
    ("youtube kholo", "open_youtube", None),
    ("open word", "open_word", None),
    ("word kholo", "open_word", None),
    ("open google", "open_google", None),
    ("microsoft word", "open_word", None),  # exact bare target name
    # --- No random action from unrelated sentences ---
    ("home page", "unknown", None),
    ("nexora home", "unknown", None),
    ("word games", "unknown", None),  # target word + extra word is not "open word"
    ("i read a story about word games and photos", "unknown", None),
    ("the volume of this book is very high", "unknown", None),
    ("close the door and lock it before you leave", "unknown", None),
    ("turn the lights off and close everything in the house", "unknown", None),
    ("tell me a story about a close friend", "unknown", None),
    ("the word mute appears in this sentence about sound", "unknown", None),
    ("i have no time for this long story", "unknown", None),
    ("this movie is about time travel", "unknown", None),
    ("my date of birth is a secret", "unknown", None),
    ("asdf home page zxcv", "unknown", None),
    # --- Positive controls: anchored short commands still fire ---
    ("what is the time", "tell_time", None),
    ("what is the date", "tell_date", None),
    ("volume up", "volume_up", None),
    ("awaz tez karo", "volume_up", None),
    ("awaz band karo", "mute", None),
    ("mute", "mute", None),
    ("close this window", "close_window", None),
    ("please close this", "close_window", None),
]

# Same traps through the full v2 entry point (v1 + multilingual):
# the multilingual fallback must not resurrect a misfire either.
CASES_V2 = [
    ("home page", "unknown", None),
    ("word games", "unknown", None),
    ("search google for word games", "google_search", "word games"),
    ("open word", "open_word", None),
]


def run(cases, parser, label):
    passed = 0
    failed = 0
    for sentence, expected_action, expected_payload in cases:
        result = parser(sentence)
        ok = result.get("action") == expected_action
        if ok and expected_payload is not None:
            payload = result.get("query", result.get("text", ""))
            ok = str(payload).lower() == expected_payload.lower()
        if ok:
            passed += 1
            print(f"PASS  [{label}] {sentence!r:55} -> {result}")
        else:
            failed += 1
            print(f"FAIL  [{label}] {sentence!r:55} -> got {result}, expected action={expected_action} payload={expected_payload}")
    return passed, failed


def main():
    p1, f1 = run(CASES, parse_command, "v1")
    p2, f2 = run(CASES_V2, parse_command_v2, "v2")
    passed, failed = p1 + p2, f1 + f2
    print()
    print(f"RESULT: {passed} passed, {failed} failed, {passed + failed} total")
    return failed


if __name__ == "__main__":
    raise SystemExit(1 if main() else 0)
