"""
Tests for Nexora v2 languages (nexora_languages.py) and the
multilingual command matcher (nexora_i18n_commands.py).

Run:
    python test_languages.py

Every test prints PASS/FAIL. The last line prints the total count.
No third-party libraries needed.
"""

from nexora_i18n_commands import parse_command_v2
from nexora_languages import LANGUAGES, REPLIES, get_replies, language_of_locale

passed = 0
failed = 0


def check(label, ok, detail=""):
    global passed, failed
    if ok:
        passed += 1
        print(f"PASS  {label}")
    else:
        failed += 1
        print(f"FAIL  {label}  {detail}")


# ---------------------------------------------------------------------------
# (a) Language list: at least 40 locales, all the expected ones present
# ---------------------------------------------------------------------------
EXPECTED_CODES = [
    "en-US", "en-GB", "ur-PK", "hi-IN", "pa-IN", "bn-BD", "ar-SA", "ar-EG",
    "fa-IR", "tr-TR", "es-ES", "es-MX", "fr-FR", "de-DE", "it-IT", "pt-PT",
    "pt-BR", "ru-RU", "uk-UA", "zh-CN", "zh-TW", "ja-JP", "ko-KR", "id-ID",
    "ms-MY", "th-TH", "vi-VN", "nl-NL", "pl-PL", "sv-SE", "da-DK", "fi-FI",
    "no-NO", "el-GR", "he-IL", "sw-KE", "am-ET", "ne-NP", "si-LK", "ta-IN",
    "te-IN", "mr-IN", "gu-IN", "kn-IN", "ml-IN", "ps-AF", "sd-PK", "sr-RS",
    "hr-HR", "cs-CZ", "sk-SK", "hu-HU", "ro-RO", "bg-BG", "ca-ES", "fil-PH",
    "my-MM", "km-KH", "lo-LA", "uz-UZ", "kk-KZ", "az-AZ",
]
codes = [code for _name, code in LANGUAGES]
check(f"at least 40 locales (got {len(codes)})", len(codes) >= 40)
check(f"at least 60 locales (got {len(codes)})", len(codes) >= 60)
for code in EXPECTED_CODES:
    check(f"locale present: {code}", code in codes)
check("locale codes unique", len(codes) == len(set(codes)))
for key_code in ("ur-PK", "hi-IN", "ar-SA", "zh-CN"):
    check(f"key locale present: {key_code}", key_code in codes)

# ---------------------------------------------------------------------------
# (b) Localised replies exist and are complete for the required languages
# ---------------------------------------------------------------------------
REQUIRED_REPLY_LANGS = [
    "en", "ur", "hi", "ar", "es", "fr", "de", "tr", "bn", "pa", "ru",
    "zh", "ja", "ko", "pt", "it", "fa", "ps", "sd", "ta", "te",
]
REPLY_KEYS = ["opening", "searching", "typing", "not_understood",
              "greeting", "time_intro", "date_intro"]
for lang in REQUIRED_REPLY_LANGS:
    rep = REPLIES.get(lang)
    check(f"replies exist: {lang}", rep is not None)
    if rep:
        for key in REPLY_KEYS:
            check(f"reply {lang}.{key} non-empty",
                  isinstance(rep.get(key), str) and bool(rep[key].strip()))
        # templates must accept their placeholders without error
        try:
            rep["opening"].format(target="YouTube")
            rep["searching"].format(query="cats")
            rep["typing"].format(text="hello")
            rep["time_intro"].format(value="4:35 PM")
            rep["date_intro"].format(value="7 November 2026")
            check(f"reply templates format: {lang}", True)
        except Exception as exc:
            check(f"reply templates format: {lang}", False, str(exc))

check("get_replies('ur-PK') is Urdu", get_replies("ur-PK") is REPLIES["ur"])
check("get_replies('hi-IN') is Hindi", get_replies("hi-IN") is REPLIES["hi"])
check("get_replies('ar-EG') is Arabic", get_replies("ar-EG") is REPLIES["ar"])
check("get_replies('pt-BR') is Portuguese", get_replies("pt-BR") is REPLIES["pt"])
check("get_replies('sw-KE') falls back to English",
      get_replies("sw-KE") is REPLIES["en"])
check("get_replies('uk-UA') falls back to English",
      get_replies("uk-UA") is REPLIES["en"])
check("language_of_locale('zh-CN') == 'zh'", language_of_locale("zh-CN") == "zh")

# ---------------------------------------------------------------------------
# (c) Multilingual command matching - at least 2 per keyword language
# ---------------------------------------------------------------------------
CASES = [
    # Urdu (script)
    ("ورڈ کھولو", "open_word", None),
    ("یوٹیوب کھولو", "open_youtube", None),
    ("بلیاں تلاش کرو", "google_search", "بلیاں"),
    # Hindi
    ("वर्ड खोलो", "open_word", None),
    ("यूट्यूब खोलो", "open_youtube", None),
    ("बिल्लियाँ खोजो", "google_search", "बिल्लियाँ"),
    ("लिखो मेरा नाम अहमद है", "dictate", "मेरा नाम अहमद है"),
    ("बंद करो", "close_window", None),
    # Arabic
    ("افتح يوتيوب", "open_youtube", None),
    ("افتح وورد", "open_word", None),
    ("ابحث عن القطط", "google_search", "القطط"),
    ("اكتب مرحبا بالعالم", "dictate", "مرحبا بالعالم"),
    # Spanish
    ("abre youtube", "open_youtube", None),
    ("abre word", "open_word", None),
    ("busca gatos", "google_search", "gatos"),
    ("cierra esto", "close_window", None),
    # French
    ("ouvre youtube", "open_youtube", None),
    ("ouvre word", "open_word", None),
    ("cherche chats", "google_search", "chats"),
    # German
    ("öffne youtube", "open_youtube", None),
    ("öffne word", "open_word", None),
    ("suche katzen", "google_search", "katzen"),
    # Turkish
    ("youtube aç", "open_youtube", None),
    ("word aç", "open_word", None),
    ("kedileri ara", "google_search", "kedileri"),
    # Russian
    ("открой ютуб", "open_youtube", None),
    ("открой ворд", "open_word", None),
    ("найди кошек", "google_search", "кошек"),
    # Bengali
    ("ওয়ার্ড খোলো", "open_word", None),
    ("ইউটিউব খোলো", "open_youtube", None),
    # Punjabi
    ("ਵਰਡ ਖੋਲ੍ਹੋ", "open_word", None),
    ("ਯੂਟਿਊਬ ਖੋਲ੍ਹੋ", "open_youtube", None),
    # v1 regression spot-checks through the v2 entry point
    ("word kholo", "open_word", None),
    ("cats search karo", "google_search", "cats"),
    ("likho mera naam Ahmad hai", "dictate", "mera naam Ahmad hai"),
    ("open youtube", "open_youtube", None),
]

for sentence, expected_action, expected_payload in CASES:
    result = parse_command_v2(sentence)
    ok = result.get("action") == expected_action
    if ok and expected_payload is not None:
        payload = result.get("query", result.get("text", ""))
        ok = str(payload).strip() == expected_payload
    check(f"cmd {sentence!r} -> {expected_action}", ok,
          f"got {result}")

print()
print(f"RESULT: {passed} passed, {failed} failed, {passed + failed} total")

if __name__ == "__main__":
    raise SystemExit(1 if failed else 0)
